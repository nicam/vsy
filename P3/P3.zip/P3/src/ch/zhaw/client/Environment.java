package ch.zhaw.client;

public abstract class Environment {
    //public static String host = "188.40.90.140";
    //public static int port = 1234;

    public static String host = "localhost";
    public static int port = 1234;
}
